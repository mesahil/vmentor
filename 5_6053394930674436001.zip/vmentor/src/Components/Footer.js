import React from 'react'
import '../Styles/Footer.css'

function Footer() {
  return (
    <div className='footer'>
        <h4>Copyright © 2020 | VANS Skilling & Advisory</h4>
        <h4>Powered By Gorebo.com</h4>
    </div>
  )
}

export default Footer